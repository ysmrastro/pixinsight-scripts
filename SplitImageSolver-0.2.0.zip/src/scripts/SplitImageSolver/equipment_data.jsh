// equipment_data.jsh - Equipment database for SplitImageSolver
// This file is #included to ensure the data is always available,
// regardless of the script's runtime working directory.
// Converted from config/equipment.yaml - keep in sync when editing.

var __equipmentData__ = {
  "cameras": [
    // ===== Sony alpha7 (Standard) =====
    {
      "name": "Sony \u03b17",
      "instrume": "Sony ILCE-7",
      "pixel_pitch": 5.97,
      "sensor_width": 6000,
      "sensor_height": 4000
    },
    {
      "name": "Sony \u03b17II",
      "instrume": "Sony ILCE-7M2",
      "pixel_pitch": 5.97,
      "sensor_width": 6000,
      "sensor_height": 4000
    },
    {
      "name": "Sony \u03b17III",
      "instrume": "Sony ILCE-7M3",
      "pixel_pitch": 5.93,
      "sensor_width": 6000,
      "sensor_height": 4000
    },
    {
      "name": "Sony \u03b17IV",
      "instrume": "Sony ILCE-7M4",
      "pixel_pitch": 5.12,
      "sensor_width": 7008,
      "sensor_height": 4672
    },
    {
      "name": "Sony \u03b17V",
      "instrume": "Sony ILCE-7M5",
      "pixel_pitch": 5.08,
      "sensor_width": 7008,
      "sensor_height": 4672
    },
    // ===== Sony alpha7R (High Resolution) =====
    {
      "name": "Sony \u03b17R",
      "instrume": "Sony ILCE-7R",
      "pixel_pitch": 4.88,
      "sensor_width": 7360,
      "sensor_height": 4912
    },
    {
      "name": "Sony \u03b17RII",
      "instrume": "Sony ILCE-7RM2",
      "pixel_pitch": 4.52,
      "sensor_width": 7952,
      "sensor_height": 5304
    },
    {
      "name": "Sony \u03b17RIII",
      "instrume": "Sony ILCE-7RM3",
      "pixel_pitch": 4.52,
      "sensor_width": 7952,
      "sensor_height": 5304
    },
    {
      "name": "Sony \u03b17RIV",
      "instrume": "Sony ILCE-7RM4",
      "pixel_pitch": 3.76,
      "sensor_width": 9504,
      "sensor_height": 6336
    },
    {
      "name": "Sony \u03b17RV",
      "instrume": "Sony ILCE-7RM5",
      "pixel_pitch": 3.76,
      "sensor_width": 9504,
      "sensor_height": 6336
    },
    // ===== Sony alpha7S (High Sensitivity) =====
    {
      "name": "Sony \u03b17S",
      "instrume": "Sony ILCE-7S",
      "pixel_pitch": 8.45,
      "sensor_width": 4240,
      "sensor_height": 2832
    },
    {
      "name": "Sony \u03b17SII",
      "instrume": "Sony ILCE-7SM2",
      "pixel_pitch": 8.40,
      "sensor_width": 4240,
      "sensor_height": 2832
    },
    {
      "name": "Sony \u03b17SIII",
      "instrume": "Sony ILCE-7SM3",
      "pixel_pitch": 8.40,
      "sensor_width": 4240,
      "sensor_height": 2832
    },
    // ===== Sony alpha7C (Compact) =====
    {
      "name": "Sony \u03b17C",
      "instrume": "Sony ILCE-7C",
      "pixel_pitch": 5.94,
      "sensor_width": 6000,
      "sensor_height": 4000
    },
    {
      "name": "Sony \u03b17CII",
      "instrume": "Sony ILCE-7CM2",
      "pixel_pitch": 5.12,
      "sensor_width": 7008,
      "sensor_height": 4672
    },
    {
      "name": "Sony \u03b17CR",
      "instrume": "Sony ILCE-7CR",
      "pixel_pitch": 3.76,
      "sensor_width": 9504,
      "sensor_height": 6336
    },
    // ===== Nikon Z (24MP class) =====
    {
      "name": "Nikon Z 5",
      "instrume": "NIKON Z 5",
      "pixel_pitch": 5.97,
      "sensor_width": 6016,
      "sensor_height": 4016
    },
    {
      "name": "Nikon Z 5II",
      "instrume": "NIKON Z5_2",
      "pixel_pitch": 5.94,
      "sensor_width": 6048,
      "sensor_height": 4032
    },
    {
      "name": "Nikon Z 6",
      "instrume": "NIKON Z 6",
      "pixel_pitch": 5.94,
      "sensor_width": 6048,
      "sensor_height": 4024
    },
    {
      "name": "Nikon Z 6II",
      "instrume": "NIKON Z 6_2",
      "pixel_pitch": 5.94,
      "sensor_width": 6048,
      "sensor_height": 4024
    },
    {
      "name": "Nikon Z 6III",
      "instrume": "NIKON Z 6_3",
      "pixel_pitch": 5.94,
      "sensor_width": 6048,
      "sensor_height": 4032
    },
    {
      "name": "Nikon Z f",
      "instrume": "NIKON Z f",
      "pixel_pitch": 5.94,
      "sensor_width": 6048,
      "sensor_height": 4032
    },
    // ===== Nikon Z (45MP class) =====
    {
      "name": "Nikon Z 7",
      "instrume": "NIKON Z 7",
      "pixel_pitch": 4.35,
      "sensor_width": 8256,
      "sensor_height": 5504
    },
    {
      "name": "Nikon Z 7II",
      "instrume": "NIKON Z 7_2",
      "pixel_pitch": 4.35,
      "sensor_width": 8256,
      "sensor_height": 5504
    },
    {
      "name": "Nikon Z 8",
      "instrume": "NIKON Z 8",
      "pixel_pitch": 4.35,
      "sensor_width": 8256,
      "sensor_height": 5504
    },
    {
      "name": "Nikon Z 9",
      "instrume": "NIKON Z 9",
      "pixel_pitch": 4.35,
      "sensor_width": 8256,
      "sensor_height": 5504
    },
    // ===== Nikon DSLR =====
    {
      "name": "Nikon D810A",
      "instrume": "NIKON D810A",
      "pixel_pitch": 4.88,
      "sensor_width": 7360,
      "sensor_height": 4912
    },
    {
      "name": "Nikon D850",
      "instrume": "NIKON D850",
      "pixel_pitch": 4.34,
      "sensor_width": 8256,
      "sensor_height": 5504
    },
    {
      "name": "Nikon D750",
      "instrume": "NIKON D750",
      "pixel_pitch": 5.94,
      "sensor_width": 6016,
      "sensor_height": 4016
    },
    {
      "name": "Nikon D5600",
      "instrume": "NIKON D5600",
      "pixel_pitch": 3.89,
      "sensor_width": 6000,
      "sensor_height": 4000
    },
    // ===== Canon EOS R (Standard) =====
    {
      "name": "Canon EOS R",
      "instrume": "Canon EOS R",
      "pixel_pitch": 5.36,
      "sensor_width": 6720,
      "sensor_height": 4480
    },
    {
      "name": "Canon EOS Ra",
      "instrume": "Canon EOS Ra",
      "pixel_pitch": 5.36,
      "sensor_width": 6720,
      "sensor_height": 4480
    },
    {
      "name": "Canon EOS RP",
      "instrume": "Canon EOS RP",
      "pixel_pitch": 5.75,
      "sensor_width": 6240,
      "sensor_height": 4160
    },
    {
      "name": "Canon EOS R3",
      "instrume": "Canon EOS R3",
      "pixel_pitch": 5.98,
      "sensor_width": 6000,
      "sensor_height": 4000
    },
    {
      "name": "Canon EOS R6",
      "instrume": "Canon EOS R6",
      "pixel_pitch": 6.58,
      "sensor_width": 5472,
      "sensor_height": 3648
    },
    {
      "name": "Canon EOS R6 II",
      "instrume": "Canon EOS R6 Mark II",
      "pixel_pitch": 5.98,
      "sensor_width": 6000,
      "sensor_height": 4000
    },
    {
      "name": "Canon EOS R6 III",
      "instrume": "Canon EOS R6 Mark III",
      "pixel_pitch": 5.16,
      "sensor_width": 6960,
      "sensor_height": 4640
    },
    {
      "name": "Canon EOS R8",
      "instrume": "Canon EOS R8",
      "pixel_pitch": 5.98,
      "sensor_width": 6000,
      "sensor_height": 4000
    },
    // ===== Canon EOS R (High Resolution / Flagship) =====
    {
      "name": "Canon EOS R5",
      "instrume": "Canon EOS R5",
      "pixel_pitch": 4.39,
      "sensor_width": 8192,
      "sensor_height": 5464
    },
    {
      "name": "Canon EOS R5 II",
      "instrume": "Canon EOS R5 Mark II",
      "pixel_pitch": 4.39,
      "sensor_width": 8192,
      "sensor_height": 5464
    },
    {
      "name": "Canon EOS R1",
      "instrume": "Canon EOS R1",
      "pixel_pitch": 6.00,
      "sensor_width": 6000,
      "sensor_height": 4000
    },
    // ===== Canon DSLR =====
    {
      "name": "Canon EOS 6D",
      "instrume": "Canon EOS 6D",
      "pixel_pitch": 6.55,
      "sensor_width": 5472,
      "sensor_height": 3648
    },
    {
      "name": "Canon EOS 6D Mark II",
      "instrume": "Canon EOS 6D Mark II",
      "pixel_pitch": 5.73,
      "sensor_width": 6240,
      "sensor_height": 4160
    },
    {
      "name": "Canon EOS 5D Mark IV",
      "instrume": "Canon EOS 5D Mark IV",
      "pixel_pitch": 5.36,
      "sensor_width": 6720,
      "sensor_height": 4480
    },
    {
      "name": "Canon EOS 60Da",
      "instrume": "Canon EOS 60Da",
      "pixel_pitch": 4.30,
      "sensor_width": 5184,
      "sensor_height": 3456
    },
    {
      "name": "Canon EOS 80D",
      "instrume": "Canon EOS 80D",
      "pixel_pitch": 3.71,
      "sensor_width": 6000,
      "sensor_height": 4000
    },
    // ===== ZWO =====
    {
      "name": "ZWO ASI2600MC Pro",
      "instrume": "ZWO ASI2600MC Pro",
      "pixel_pitch": 3.76,
      "sensor_width": 6248,
      "sensor_height": 4176
    },
    {
      "name": "ZWO ASI2600MM Pro",
      "instrume": "ZWO ASI2600MM Pro",
      "pixel_pitch": 3.76,
      "sensor_width": 6248,
      "sensor_height": 4176
    },
    {
      "name": "ZWO ASI294MC Pro",
      "instrume": "ZWO ASI294MC Pro",
      "pixel_pitch": 4.63,
      "sensor_width": 4144,
      "sensor_height": 2822
    },
    {
      "name": "ZWO ASI294MM Pro",
      "instrume": "ZWO ASI294MM Pro",
      "pixel_pitch": 4.63,
      "sensor_width": 4144,
      "sensor_height": 2822
    },
    {
      "name": "ZWO ASI533MC Pro",
      "instrume": "ZWO ASI533MC Pro",
      "pixel_pitch": 3.76,
      "sensor_width": 3008,
      "sensor_height": 3008
    },
    {
      "name": "ZWO ASI071MC Pro",
      "instrume": "ZWO ASI071MC Pro",
      "pixel_pitch": 4.78,
      "sensor_width": 4944,
      "sensor_height": 3284
    },
    {
      "name": "ZWO ASI183MC Pro",
      "instrume": "ZWO ASI183MC Pro",
      "pixel_pitch": 2.40,
      "sensor_width": 5496,
      "sensor_height": 3672
    },
    {
      "name": "ZWO ASI585MC",
      "instrume": "ZWO ASI585MC",
      "pixel_pitch": 2.90,
      "sensor_width": 3840,
      "sensor_height": 2160
    },
    {
      "name": "ZWO ASI678MC",
      "instrume": "ZWO ASI678MC",
      "pixel_pitch": 2.00,
      "sensor_width": 3840,
      "sensor_height": 2160
    },
    {
      "name": "ZWO ASI6200MM Pro",
      "instrume": "ZWO ASI6200MM Pro",
      "pixel_pitch": 3.76,
      "sensor_width": 9576,
      "sensor_height": 6388
    },
    {
      "name": "ZWO ASI6200MC Pro",
      "instrume": "ZWO ASI6200MC Pro",
      "pixel_pitch": 3.76,
      "sensor_width": 9576,
      "sensor_height": 6388
    },
    // ===== QHY =====
    {
      "name": "QHY268M",
      "instrume": "QHY268M",
      "pixel_pitch": 3.76,
      "sensor_width": 6252,
      "sensor_height": 4176
    },
    {
      "name": "QHY268C",
      "instrume": "QHY268C",
      "pixel_pitch": 3.76,
      "sensor_width": 6252,
      "sensor_height": 4176
    },
    {
      "name": "QHY600M",
      "instrume": "QHY600M",
      "pixel_pitch": 3.76,
      "sensor_width": 9576,
      "sensor_height": 6388
    },
    {
      "name": "QHY533M",
      "instrume": "QHY533M",
      "pixel_pitch": 3.76,
      "sensor_width": 3008,
      "sensor_height": 3008
    },
    {
      "name": "QHY294M Pro",
      "instrume": "QHY294M-Pro",
      "pixel_pitch": 4.63,
      "sensor_width": 4144,
      "sensor_height": 2822
    },
    {
      "name": "QHY183M",
      "instrume": "QHY183M",
      "pixel_pitch": 2.40,
      "sensor_width": 5496,
      "sensor_height": 3672
    },
    // ===== Player One =====
    {
      "name": "Player One Poseidon-C Pro",
      "instrume": "Player One Poseidon-C Pro",
      "pixel_pitch": 3.76,
      "sensor_width": 6248,
      "sensor_height": 4176
    },
    {
      "name": "Player One Artemis-C Pro",
      "instrume": "Player One Artemis-C Pro",
      "pixel_pitch": 4.63,
      "sensor_width": 4144,
      "sensor_height": 2822
    },
    // ===== Custom =====
    {
      "name": "Custom",
      "instrume": "",
      "pixel_pitch": 0,
      "sensor_width": 0,
      "sensor_height": 0
    }
  ],
  "lenses": [
    // ===== Fisheye =====
    {"name": "8mm Fisheye", "focal_length": 8, "projection": "equisolid"},
    {"name": "10mm Fisheye", "focal_length": 10, "projection": "equisolid"},
    {"name": "Sigma 15mm f/2.8 EX DG Fisheye", "focal_length": 15, "projection": "equisolid"},
    // ===== Sony FE =====
    {"name": "Sony FE 14mm f/1.8 GM", "focal_length": 14, "projection": "rectilinear"},
    {"name": "Sony FE 20mm f/1.8 G", "focal_length": 20, "projection": "rectilinear"},
    {"name": "Sony FE 24mm f/1.4 GM", "focal_length": 24, "projection": "rectilinear"},
    {"name": "Sony FE 24mm f/2.8 G", "focal_length": 24, "projection": "rectilinear"},
    {"name": "Sony FE 35mm f/1.4 GM", "focal_length": 35, "projection": "rectilinear"},
    // ===== Sigma Art / Contemporary =====
    {"name": "Sigma 14mm f/1.4 DG DN Art", "focal_length": 14, "projection": "rectilinear"},
    {"name": "Sigma 20mm f/1.4 DG DN Art", "focal_length": 20, "projection": "rectilinear"},
    {"name": "Sigma 24mm f/2 DG DN Contemp.", "focal_length": 24, "projection": "rectilinear"},
    {"name": "Sigma 24mm f/3.5 DG DN Contemp.", "focal_length": 24, "projection": "rectilinear"},
    {"name": "Sigma 35mm f/1.2 DG DN Art", "focal_length": 35, "projection": "rectilinear"},
    {"name": "Sigma 35mm f/1.4 DG DN Art", "focal_length": 35, "projection": "rectilinear"},
    {"name": "Sigma 35mm f/2 DG DN Contemp.", "focal_length": 35, "projection": "rectilinear"},
    // ===== NIKKOR Z =====
    {"name": "NIKKOR Z 20mm f/1.8 S", "focal_length": 20, "projection": "rectilinear"},
    {"name": "NIKKOR Z 24mm f/1.8 S", "focal_length": 24, "projection": "rectilinear"},
    {"name": "NIKKOR Z 26mm f/2.8", "focal_length": 26, "projection": "rectilinear"},
    {"name": "NIKKOR Z 28mm f/2.8", "focal_length": 28, "projection": "rectilinear"},
    {"name": "NIKKOR Z 35mm f/1.2 S", "focal_length": 35, "projection": "rectilinear"},
    {"name": "NIKKOR Z 35mm f/1.4", "focal_length": 35, "projection": "rectilinear"},
    {"name": "NIKKOR Z 35mm f/1.8 S", "focal_length": 35, "projection": "rectilinear"},
    // ===== Canon RF =====
    {"name": "Canon RF 14mm f/1.4 L VCM", "focal_length": 14, "projection": "rectilinear"},
    {"name": "Canon RF 16mm f/2.8 STM", "focal_length": 16, "projection": "rectilinear"},
    {"name": "Canon RF 20mm f/1.4 L VCM", "focal_length": 20, "projection": "rectilinear"},
    {"name": "Canon RF 24mm f/1.4 L VCM", "focal_length": 24, "projection": "rectilinear"},
    {"name": "Canon RF 24mm f/1.8 Macro IS STM", "focal_length": 24, "projection": "rectilinear"},
    {"name": "Canon RF 28mm f/2.8 STM", "focal_length": 28, "projection": "rectilinear"},
    {"name": "Canon RF 35mm f/1.4 L VCM", "focal_length": 35, "projection": "rectilinear"},
    {"name": "Canon RF 35mm f/1.8 Macro IS STM", "focal_length": 35, "projection": "rectilinear"},
    // ===== Generic focal lengths =====
    {"name": "50mm", "focal_length": 50, "projection": "rectilinear"},
    {"name": "85mm", "focal_length": 85, "projection": "rectilinear"},
    {"name": "100mm", "focal_length": 100, "projection": "rectilinear"},
    {"name": "135mm", "focal_length": 135, "projection": "rectilinear"},
    {"name": "200mm", "focal_length": 200, "projection": "rectilinear"},
    // ===== Telescopes =====
    {"name": "250mm (RedCat 51)", "focal_length": 250, "projection": "rectilinear"},
    {"name": "300mm", "focal_length": 300, "projection": "rectilinear"},
    {"name": "400mm", "focal_length": 400, "projection": "rectilinear"},
    {"name": "500mm", "focal_length": 500, "projection": "rectilinear"},
    {"name": "600mm", "focal_length": 600, "projection": "rectilinear"},
    {"name": "714mm (RASA 8)", "focal_length": 714, "projection": "rectilinear"},
    {"name": "800mm", "focal_length": 800, "projection": "rectilinear"},
    {"name": "1000mm", "focal_length": 1000, "projection": "rectilinear"},
    {"name": "1200mm", "focal_length": 1200, "projection": "rectilinear"},
    {"name": "1600mm", "focal_length": 1600, "projection": "rectilinear"},
    {"name": "2000mm", "focal_length": 2000, "projection": "rectilinear"},
    {"name": "2350mm (C9.25)", "focal_length": 2350, "projection": "rectilinear"},
    // ===== Custom =====
    {"name": "Custom", "focal_length": 0, "projection": "rectilinear"}
  ]
};
