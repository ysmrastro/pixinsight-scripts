// equipment_data.jsh - Equipment database for SplitImageSolver
// This file is #included to ensure the data is always available,
// regardless of the script's runtime working directory.
// Converted from config/equipment.yaml - keep in sync when editing.

var __equipmentData__ = {
  "cameras": [
    // ===== Sony alpha7 (Standard) =====
    {
      "name": "Sony \u03b17",
      "instrume": "Sony ILCE-7",
      "pixel_pitch": 5.97,
      "sensor_width": 6000,
      "sensor_height": 4000
    },
    {
      "name": "Sony \u03b17II",
      "instrume": "Sony ILCE-7M2",
      "pixel_pitch": 5.97,
      "sensor_width": 6000,
      "sensor_height": 4000
    },
    {
      "name": "Sony \u03b17III",
      "instrume": "Sony ILCE-7M3",
      "pixel_pitch": 5.93,
      "sensor_width": 6000,
      "sensor_height": 4000
    },
    {
      "name": "Sony \u03b17IV",
      "instrume": "Sony ILCE-7M4",
      "pixel_pitch": 5.12,
      "sensor_width": 7008,
      "sensor_height": 4672
    },
    {
      "name": "Sony \u03b17V",
      "instrume": "Sony ILCE-7M5",
      "pixel_pitch": 5.08,
      "sensor_width": 7008,
      "sensor_height": 4672
    },
    // ===== Sony alpha7R (High Resolution) =====
    {
      "name": "Sony \u03b17R",
      "instrume": "Sony ILCE-7R",
      "pixel_pitch": 4.88,
      "sensor_width": 7360,
      "sensor_height": 4912
    },
    {
      "name": "Sony \u03b17RII",
      "instrume": "Sony ILCE-7RM2",
      "pixel_pitch": 4.52,
      "sensor_width": 7952,
      "sensor_height": 5304
    },
    {
      "name": "Sony \u03b17RIII",
      "instrume": "Sony ILCE-7RM3",
      "pixel_pitch": 4.52,
      "sensor_width": 7952,
      "sensor_height": 5304
    },
    {
      "name": "Sony \u03b17RIV",
      "instrume": "Sony ILCE-7RM4",
      "pixel_pitch": 3.76,
      "sensor_width": 9504,
      "sensor_height": 6336
    },
    {
      "name": "Sony \u03b17RV",
      "instrume": "Sony ILCE-7RM5",
      "pixel_pitch": 3.76,
      "sensor_width": 9504,
      "sensor_height": 6336
    },
    // ===== Sony alpha7S (High Sensitivity) =====
    {
      "name": "Sony \u03b17S",
      "instrume": "Sony ILCE-7S",
      "pixel_pitch": 8.45,
      "sensor_width": 4240,
      "sensor_height": 2832
    },
    {
      "name": "Sony \u03b17SII",
      "instrume": "Sony ILCE-7SM2",
      "pixel_pitch": 8.40,
      "sensor_width": 4240,
      "sensor_height": 2832
    },
    {
      "name": "Sony \u03b17SIII",
      "instrume": "Sony ILCE-7SM3",
      "pixel_pitch": 8.40,
      "sensor_width": 4240,
      "sensor_height": 2832
    },
    // ===== Sony alpha7C (Compact) =====
    {
      "name": "Sony \u03b17C",
      "instrume": "Sony ILCE-7C",
      "pixel_pitch": 5.94,
      "sensor_width": 6000,
      "sensor_height": 4000
    },
    {
      "name": "Sony \u03b17CII",
      "instrume": "Sony ILCE-7CM2",
      "pixel_pitch": 5.12,
      "sensor_width": 7008,
      "sensor_height": 4672
    },
    {
      "name": "Sony \u03b17CR",
      "instrume": "Sony ILCE-7CR",
      "pixel_pitch": 3.76,
      "sensor_width": 9504,
      "sensor_height": 6336
    },
    // ===== Sony alpha6000 (APS-C) =====
    {
      "name": "Sony \u03b16100",
      "instrume": "Sony ILCE-6100",
      "pixel_pitch": 3.92,
      "sensor_width": 6000,
      "sensor_height": 4000
    },
    // ===== Nikon Z (24MP class) =====
    {
      "name": "Nikon Z 5",
      "instrume": "NIKON Z 5",
      "pixel_pitch": 5.97,
      "sensor_width": 6016,
      "sensor_height": 4016
    },
    {
      "name": "Nikon Z 5II",
      "instrume": "NIKON Z5_2",
      "pixel_pitch": 5.94,
      "sensor_width": 6048,
      "sensor_height": 4032
    },
    {
      "name": "Nikon Z 6",
      "instrume": "NIKON Z 6",
      "pixel_pitch": 5.94,
      "sensor_width": 6048,
      "sensor_height": 4024
    },
    {
      "name": "Nikon Z 6II",
      "instrume": "NIKON Z 6_2",
      "pixel_pitch": 5.94,
      "sensor_width": 6048,
      "sensor_height": 4024
    },
    {
      "name": "Nikon Z 6III",
      "instrume": "NIKON Z 6_3",
      "pixel_pitch": 5.94,
      "sensor_width": 6048,
      "sensor_height": 4032
    },
    {
      "name": "Nikon Z f",
      "instrume": "NIKON Z f",
      "pixel_pitch": 5.94,
      "sensor_width": 6048,
      "sensor_height": 4032
    },
    // ===== Nikon Z (45MP class) =====
    {
      "name": "Nikon Z 7",
      "instrume": "NIKON Z 7",
      "pixel_pitch": 4.35,
      "sensor_width": 8256,
      "sensor_height": 5504
    },
    {
      "name": "Nikon Z 7II",
      "instrume": "NIKON Z 7_2",
      "pixel_pitch": 4.35,
      "sensor_width": 8256,
      "sensor_height": 5504
    },
    {
      "name": "Nikon Z 8",
      "instrume": "NIKON Z 8",
      "pixel_pitch": 4.35,
      "sensor_width": 8256,
      "sensor_height": 5504
    },
    {
      "name": "Nikon Z 9",
      "instrume": "NIKON Z 9",
      "pixel_pitch": 4.35,
      "sensor_width": 8256,
      "sensor_height": 5504
    },
    // ===== Nikon DSLR =====
    {
      "name": "Nikon D810A",
      "instrume": "NIKON D810A",
      "pixel_pitch": 4.88,
      "sensor_width": 7360,
      "sensor_height": 4912
    },
    {
      "name": "Nikon D850",
      "instrume": "NIKON D850",
      "pixel_pitch": 4.34,
      "sensor_width": 8256,
      "sensor_height": 5504
    },
    {
      "name": "Nikon D750",
      "instrume": "NIKON D750",
      "pixel_pitch": 5.94,
      "sensor_width": 6016,
      "sensor_height": 4016
    },
    {
      "name": "Nikon D5600",
      "instrume": "NIKON D5600",
      "pixel_pitch": 3.89,
      "sensor_width": 6000,
      "sensor_height": 4000
    },
    // ===== Canon EOS R (Standard) =====
    {
      "name": "Canon EOS R",
      "instrume": "Canon EOS R",
      "pixel_pitch": 5.36,
      "sensor_width": 6720,
      "sensor_height": 4480
    },
    {
      "name": "Canon EOS Ra",
      "instrume": "Canon EOS Ra",
      "pixel_pitch": 5.36,
      "sensor_width": 6720,
      "sensor_height": 4480
    },
    {
      "name": "Canon EOS RP",
      "instrume": "Canon EOS RP",
      "pixel_pitch": 5.75,
      "sensor_width": 6240,
      "sensor_height": 4160
    },
    {
      "name": "Canon EOS R3",
      "instrume": "Canon EOS R3",
      "pixel_pitch": 5.98,
      "sensor_width": 6000,
      "sensor_height": 4000
    },
    {
      "name": "Canon EOS R6",
      "instrume": "Canon EOS R6",
      "pixel_pitch": 6.58,
      "sensor_width": 5472,
      "sensor_height": 3648
    },
    {
      "name": "Canon EOS R6 II",
      "instrume": "Canon EOS R6 Mark II",
      "pixel_pitch": 5.98,
      "sensor_width": 6000,
      "sensor_height": 4000
    },
    {
      "name": "Canon EOS R6 III",
      "instrume": "Canon EOS R6 Mark III",
      "pixel_pitch": 5.16,
      "sensor_width": 6960,
      "sensor_height": 4640
    },
    {
      "name": "Canon EOS R8",
      "instrume": "Canon EOS R8",
      "pixel_pitch": 5.98,
      "sensor_width": 6000,
      "sensor_height": 4000
    },
    // ===== Canon EOS R (High Resolution / Flagship) =====
    {
      "name": "Canon EOS R5",
      "instrume": "Canon EOS R5",
      "pixel_pitch": 4.39,
      "sensor_width": 8192,
      "sensor_height": 5464
    },
    {
      "name": "Canon EOS R5 II",
      "instrume": "Canon EOS R5 Mark II",
      "pixel_pitch": 4.39,
      "sensor_width": 8192,
      "sensor_height": 5464
    },
    {
      "name": "Canon EOS R1",
      "instrume": "Canon EOS R1",
      "pixel_pitch": 6.00,
      "sensor_width": 6000,
      "sensor_height": 4000
    },
    // ===== Canon DSLR =====
    {
      "name": "Canon EOS 6D",
      "instrume": "Canon EOS 6D",
      "pixel_pitch": 6.55,
      "sensor_width": 5472,
      "sensor_height": 3648
    },
    {
      "name": "Canon EOS 6D Mark II",
      "instrume": "Canon EOS 6D Mark II",
      "pixel_pitch": 5.73,
      "sensor_width": 6240,
      "sensor_height": 4160
    },
    {
      "name": "Canon EOS 5D Mark IV",
      "instrume": "Canon EOS 5D Mark IV",
      "pixel_pitch": 5.36,
      "sensor_width": 6720,
      "sensor_height": 4480
    },
    {
      "name": "Canon EOS 60Da",
      "instrume": "Canon EOS 60Da",
      "pixel_pitch": 4.30,
      "sensor_width": 5184,
      "sensor_height": 3456
    },
    {
      "name": "Canon EOS 80D",
      "instrume": "Canon EOS 80D",
      "pixel_pitch": 3.71,
      "sensor_width": 6000,
      "sensor_height": 4000
    },
    // ===== ZWO =====
    {
      "name": "ZWO ASI2600MC Pro",
      "instrume": "ZWO ASI2600MC Pro",
      "pixel_pitch": 3.76,
      "sensor_width": 6248,
      "sensor_height": 4176
    },
    {
      "name": "ZWO ASI2600MM Pro",
      "instrume": "ZWO ASI2600MM Pro",
      "pixel_pitch": 3.76,
      "sensor_width": 6248,
      "sensor_height": 4176
    },
    {
      "name": "ZWO ASI294MC Pro",
      "instrume": "ZWO ASI294MC Pro",
      "pixel_pitch": 4.63,
      "sensor_width": 4144,
      "sensor_height": 2822
    },
    {
      "name": "ZWO ASI294MM Pro",
      "instrume": "ZWO ASI294MM Pro",
      "pixel_pitch": 4.63,
      "sensor_width": 4144,
      "sensor_height": 2822
    },
    {
      "name": "ZWO ASI533MC Pro",
      "instrume": "ZWO ASI533MC Pro",
      "pixel_pitch": 3.76,
      "sensor_width": 3008,
      "sensor_height": 3008
    },
    {
      "name": "ZWO ASI071MC Pro",
      "instrume": "ZWO ASI071MC Pro",
      "pixel_pitch": 4.78,
      "sensor_width": 4944,
      "sensor_height": 3284
    },
    {
      "name": "ZWO ASI183MC Pro",
      "instrume": "ZWO ASI183MC Pro",
      "pixel_pitch": 2.40,
      "sensor_width": 5496,
      "sensor_height": 3672
    },
    {
      "name": "ZWO ASI585MC",
      "instrume": "ZWO ASI585MC",
      "pixel_pitch": 2.90,
      "sensor_width": 3840,
      "sensor_height": 2160
    },
    {
      "name": "ZWO ASI678MC",
      "instrume": "ZWO ASI678MC",
      "pixel_pitch": 2.00,
      "sensor_width": 3840,
      "sensor_height": 2160
    },
    {
      "name": "ZWO ASI6200MM Pro",
      "instrume": "ZWO ASI6200MM Pro",
      "pixel_pitch": 3.76,
      "sensor_width": 9576,
      "sensor_height": 6388
    },
    {
      "name": "ZWO ASI6200MC Pro",
      "instrume": "ZWO ASI6200MC Pro",
      "pixel_pitch": 3.76,
      "sensor_width": 9576,
      "sensor_height": 6388
    },
    // ===== QHY =====
    {
      "name": "QHY268M",
      "instrume": "QHY268M",
      "pixel_pitch": 3.76,
      "sensor_width": 6252,
      "sensor_height": 4176
    },
    {
      "name": "QHY268C",
      "instrume": "QHY268C",
      "pixel_pitch": 3.76,
      "sensor_width": 6252,
      "sensor_height": 4176
    },
    {
      "name": "QHY600M",
      "instrume": "QHY600M",
      "pixel_pitch": 3.76,
      "sensor_width": 9576,
      "sensor_height": 6388
    },
    {
      "name": "QHY533M",
      "instrume": "QHY533M",
      "pixel_pitch": 3.76,
      "sensor_width": 3008,
      "sensor_height": 3008
    },
    {
      "name": "QHY294M Pro",
      "instrume": "QHY294M-Pro",
      "pixel_pitch": 4.63,
      "sensor_width": 4144,
      "sensor_height": 2822
    },
    {
      "name": "QHY183M",
      "instrume": "QHY183M",
      "pixel_pitch": 2.40,
      "sensor_width": 5496,
      "sensor_height": 3672
    },
    // ===== Player One =====
    {
      "name": "Player One Poseidon-C Pro",
      "instrume": "Player One Poseidon-C Pro",
      "pixel_pitch": 3.76,
      "sensor_width": 6248,
      "sensor_height": 4176
    },
    {
      "name": "Player One Artemis-C Pro",
      "instrume": "Player One Artemis-C Pro",
      "pixel_pitch": 4.63,
      "sensor_width": 4144,
      "sensor_height": 2822
    },
    // ===== ZWO Seestar =====
    {
      "name": "ZWO Seestar S50 (IMX462)",
      "instrume": "Seestar S50",
      "pixel_pitch": 2.90,
      "sensor_width": 1936,
      "sensor_height": 1096
    },
    {
      "name": "ZWO Seestar S30 (IMX662)",
      "instrume": "Seestar S30",
      "pixel_pitch": 2.90,
      "sensor_width": 1920,
      "sensor_height": 1080
    },
    // ===== DWARFLAB =====
    {
      "name": "DWARFLAB DWARF 3 (IMX678)",
      "instrume": "DWARF 3",
      "pixel_pitch": 2.00,
      "sensor_width": 3856,
      "sensor_height": 2180
    },
    {
      "name": "DWARFLAB DWARF mini (IMX662)",
      "instrume": "DWARF mini",
      "pixel_pitch": 2.90,
      "sensor_width": 1920,
      "sensor_height": 1080
    },
    // ===== Custom =====
    {
      "name": "Custom",
      "instrume": "",
      "pixel_pitch": 0,
      "sensor_width": 0,
      "sensor_height": 0
    }
  ],
  "lenses": [
    // ===== Fisheye =====
    {"name": "8mm Fisheye", "focal_length": 8, "projection": "equisolid"},
    {"name": "10mm Fisheye", "focal_length": 10, "projection": "equisolid"},
    {"name": "Sigma 15mm f/2.8 EX DG Fisheye", "model": "Sigma 15mm F2.8 EX DG Fisheye", "focal_length": 15, "projection": "equisolid"},
    {"name": "AstrHori 6.5mm F2.0 Fish-Eye", "focal_length": 6.5, "projection": "equisolid"},
    // ===== Sony FE =====
    {"name": "Sony FE 14mm f/1.8 GM", "model": "SEL14F18GM", "focal_length": 14, "projection": "rectilinear"},
    {"name": "Sony FE 20mm f/1.8 G", "model": "SEL20F18G", "focal_length": 20, "projection": "rectilinear"},
    {"name": "Sony FE 24mm f/1.4 GM", "model": "SEL24F14GM", "focal_length": 24, "projection": "rectilinear"},
    {"name": "Sony FE 24mm f/2.8 G", "model": "SEL24F28G", "focal_length": 24, "projection": "rectilinear"},
    {"name": "Sony FE 35mm f/1.4 GM", "model": "SEL35F14GM", "focal_length": 35, "projection": "rectilinear"},
    {"name": "Sony FE 35mm f/1.8", "model": "SEL35F18F", "focal_length": 35, "projection": "rectilinear"},
    {"name": "Sony FE 28mm f/2", "model": "SEL28F20", "focal_length": 28, "projection": "rectilinear"},
    {"name": "Sony FE 40mm f/2.5 G", "model": "SEL40F25G", "focal_length": 40, "projection": "rectilinear"},
    {"name": "Sony FE 50mm f/1.2 GM", "model": "SEL50F12GM", "focal_length": 50, "projection": "rectilinear"},
    {"name": "Sony FE 50mm f/1.4 ZA", "model": "SEL50F14Z", "focal_length": 50, "projection": "rectilinear"},
    {"name": "Sony FE 50mm f/1.8", "model": "SEL50F18F", "focal_length": 50, "projection": "rectilinear"},
    {"name": "Sony FE 50mm f/2.5 G", "model": "SEL50F25G", "focal_length": 50, "projection": "rectilinear"},
    {"name": "Sony FE 55mm f/1.8 ZA", "model": "SEL55F18Z", "focal_length": 55, "projection": "rectilinear"},
    {"name": "Sony FE 85mm f/1.4 GM", "model": "SEL85F14GM", "focal_length": 85, "projection": "rectilinear"},
    {"name": "Sony FE 85mm f/1.4 GM II", "model": "SEL85F14GM2", "focal_length": 85, "projection": "rectilinear"},
    {"name": "Sony FE 85mm f/1.8", "model": "SEL85F18", "focal_length": 85, "projection": "rectilinear"},
    {"name": "Sony FE 100mm f/2.8 STF GM", "model": "SEL100F28GM", "focal_length": 100, "projection": "rectilinear"},
    {"name": "Sony FE 135mm f/1.8 GM", "model": "SEL135F18GM", "focal_length": 135, "projection": "rectilinear"},
    // ===== Sigma Art / Contemporary =====
    {"name": "Sigma 14mm f/1.4 DG DN Art", "model": "14mm F1.4 Art", "focal_length": 14, "projection": "rectilinear"},
    {"name": "Sigma 20mm f/1.4 DG DN Art", "model": "20mm F1.4 Art", "focal_length": 20, "projection": "rectilinear"},
    {"name": "Sigma 24mm f/2 DG DN Contemp.", "model": "24mm F2 Contemp.", "focal_length": 24, "projection": "rectilinear"},
    {"name": "Sigma 24mm f/3.5 DG DN Contemp.", "model": "24mm F3.5 Contemp.", "focal_length": 24, "projection": "rectilinear"},
    {"name": "Sigma 35mm f/1.2 DG DN Art", "model": "35mm F1.2 Art", "focal_length": 35, "projection": "rectilinear"},
    {"name": "Sigma 35mm f/1.4 DG DN Art", "model": "35mm F1.4 Art", "focal_length": 35, "projection": "rectilinear"},
    {"name": "Sigma 35mm f/2 DG DN Contemp.", "model": "35mm F2 Contemp.", "focal_length": 35, "projection": "rectilinear"},
    {"name": "Sigma 24mm f/1.4 DG DN Art", "model": "24mm F1.4 Art", "focal_length": 24, "projection": "rectilinear"},
    {"name": "Sigma 45mm f/2.8 DG DN Contemp.", "model": "45mm F2.8 Contemp.", "focal_length": 45, "projection": "rectilinear"},
    {"name": "Sigma 50mm f/1.2 DG DN Art", "model": "50mm F1.2 Art", "focal_length": 50, "projection": "rectilinear"},
    {"name": "Sigma 50mm f/1.4 DG DN Art", "model": "50mm F1.4 Art", "focal_length": 50, "projection": "rectilinear"},
    {"name": "Sigma 65mm f/2 DG DN Contemp.", "model": "65mm F2 Contemp.", "focal_length": 65, "projection": "rectilinear"},
    {"name": "Sigma 85mm f/1.4 DG DN Art", "model": "85mm F1.4 Art", "focal_length": 85, "projection": "rectilinear"},
    {"name": "Sigma 90mm f/2.8 DG DN Contemp.", "model": "90mm F2.8 Contemp.", "focal_length": 90, "projection": "rectilinear"},
    // ===== NIKKOR Z =====
    {"name": "NIKKOR Z 20mm f/1.8 S", "model": "Z 20mm f/1.8 S", "focal_length": 20, "projection": "rectilinear"},
    {"name": "NIKKOR Z 24mm f/1.8 S", "model": "Z 24mm f/1.8 S", "focal_length": 24, "projection": "rectilinear"},
    {"name": "NIKKOR Z 26mm f/2.8", "model": "Z 26mm f/2.8", "focal_length": 26, "projection": "rectilinear"},
    {"name": "NIKKOR Z 28mm f/2.8", "model": "Z 28mm f/2.8", "focal_length": 28, "projection": "rectilinear"},
    {"name": "NIKKOR Z 35mm f/1.2 S", "model": "Z 35mm f/1.2 S", "focal_length": 35, "projection": "rectilinear"},
    {"name": "NIKKOR Z 35mm f/1.4", "model": "Z 35mm f/1.4", "focal_length": 35, "projection": "rectilinear"},
    {"name": "NIKKOR Z 35mm f/1.8 S", "model": "Z 35mm f/1.8 S", "focal_length": 35, "projection": "rectilinear"},
    {"name": "NIKKOR Z 40mm f/2", "model": "Z 40mm f/2", "focal_length": 40, "projection": "rectilinear"},
    {"name": "NIKKOR Z 50mm f/1.2 S", "model": "Z 50mm f/1.2 S", "focal_length": 50, "projection": "rectilinear"},
    {"name": "NIKKOR Z 50mm f/1.4", "model": "Z 50mm f/1.4", "focal_length": 50, "projection": "rectilinear"},
    {"name": "NIKKOR Z 50mm f/1.8 S", "model": "Z 50mm f/1.8 S", "focal_length": 50, "projection": "rectilinear"},
    {"name": "NIKKOR Z 58mm f/0.95 S Noct", "model": "Z 58mm f/0.95 S Noct", "focal_length": 58, "projection": "rectilinear"},
    {"name": "NIKKOR Z 85mm f/1.2 S", "model": "Z 85mm f/1.2 S", "focal_length": 85, "projection": "rectilinear"},
    {"name": "NIKKOR Z 85mm f/1.8 S", "model": "Z 85mm f/1.8 S", "focal_length": 85, "projection": "rectilinear"},
    {"name": "NIKKOR Z 135mm f/1.8 S Plena", "model": "Z 135mm f/1.8 S Plena", "focal_length": 135, "projection": "rectilinear"},
    // ===== Canon RF =====
    {"name": "Canon RF 14mm f/1.4 L VCM", "model": "RF 14mm f/1.4 L", "focal_length": 14, "projection": "rectilinear"},
    {"name": "Canon RF 16mm f/2.8 STM", "model": "RF 16mm f/2.8", "focal_length": 16, "projection": "rectilinear"},
    {"name": "Canon RF 20mm f/1.4 L VCM", "model": "RF 20mm f/1.4 L", "focal_length": 20, "projection": "rectilinear"},
    {"name": "Canon RF 24mm f/1.4 L VCM", "model": "RF 24mm f/1.4 L", "focal_length": 24, "projection": "rectilinear"},
    {"name": "Canon RF 24mm f/1.8 Macro IS STM", "model": "RF 24mm f/1.8 Macro", "focal_length": 24, "projection": "rectilinear"},
    {"name": "Canon RF 28mm f/2.8 STM", "model": "RF 28mm f/2.8", "focal_length": 28, "projection": "rectilinear"},
    {"name": "Canon RF 35mm f/1.4 L VCM", "model": "RF 35mm f/1.4 L", "focal_length": 35, "projection": "rectilinear"},
    {"name": "Canon RF 35mm f/1.8 Macro IS STM", "model": "RF 35mm f/1.8 Macro", "focal_length": 35, "projection": "rectilinear"},
    {"name": "Canon RF 45mm f/2.8 Macro IS STM", "model": "RF 45mm f/2.8 Macro", "focal_length": 45, "projection": "rectilinear"},
    {"name": "Canon RF 50mm f/1.2 L USM", "model": "RF 50mm f/1.2 L", "focal_length": 50, "projection": "rectilinear"},
    {"name": "Canon RF 50mm f/1.4 L VCM", "model": "RF 50mm f/1.4 L", "focal_length": 50, "projection": "rectilinear"},
    {"name": "Canon RF 50mm f/1.8 STM", "model": "RF 50mm f/1.8", "focal_length": 50, "projection": "rectilinear"},
    {"name": "Canon RF 85mm f/1.2 L USM", "model": "RF 85mm f/1.2 L", "focal_length": 85, "projection": "rectilinear"},
    {"name": "Canon RF 85mm f/1.2 L USM DS", "model": "RF 85mm f/1.2 L DS", "focal_length": 85, "projection": "rectilinear"},
    {"name": "Canon RF 85mm f/2 Macro IS STM", "model": "RF 85mm f/2 Macro", "focal_length": 85, "projection": "rectilinear"},
    {"name": "Canon RF 135mm f/1.8 L IS USM", "model": "RF 135mm f/1.8 L", "focal_length": 135, "projection": "rectilinear"},
    // ===== William Optics =====
    {"name": "William Optics RedCat 41 f/4.9", "model": "RedCat 41", "focal_length": 200, "projection": "rectilinear"},
    {"name": "William Optics RedCat 51 f/4.9", "model": "RedCat 51", "focal_length": 250, "projection": "rectilinear"},
    {"name": "William Optics RedCat 61 f/4.9", "model": "RedCat 61", "focal_length": 300, "projection": "rectilinear"},
    {"name": "William Optics RedCat 71 f/4.9", "model": "RedCat 71", "focal_length": 350, "projection": "rectilinear"},
    // ===== Takahashi =====
    {"name": "Takahashi FSQ-85EDP f/5.3", "model": "FSQ-85EDP", "focal_length": 450, "projection": "rectilinear"},
    {"name": "Takahashi FSQ-106ED f/5.0", "model": "FSQ-106ED", "focal_length": 530, "projection": "rectilinear"},
    {"name": "Takahashi FSQ-130ED f/5.0", "model": "FSQ-130ED", "focal_length": 650, "projection": "rectilinear"},
    // ===== ZWO Seestar =====
    {"name": "ZWO Seestar S50 (250mm f/5.0)", "model": "Seestar S50", "focal_length": 250, "projection": "rectilinear"},
    {"name": "ZWO Seestar S30 (150mm f/5.0)", "model": "Seestar S30", "focal_length": 150, "projection": "rectilinear"},
    // ===== DWARFLAB =====
    {"name": "DWARFLAB DWARF 3 (150mm f/4.3)", "model": "DWARF 3", "focal_length": 150, "projection": "rectilinear"},
    {"name": "DWARFLAB DWARF mini (150mm f/5.0)", "model": "DWARF mini", "focal_length": 150, "projection": "rectilinear"},
    // ===== Generic focal lengths =====
    {"name": "50mm", "focal_length": 50, "projection": "rectilinear"},
    {"name": "85mm", "focal_length": 85, "projection": "rectilinear"},
    {"name": "100mm", "focal_length": 100, "projection": "rectilinear"},
    {"name": "135mm", "focal_length": 135, "projection": "rectilinear"},
    {"name": "200mm", "focal_length": 200, "projection": "rectilinear"},
    // ===== Telescopes =====
    {"name": "250mm", "focal_length": 250, "projection": "rectilinear"},
    {"name": "300mm", "focal_length": 300, "projection": "rectilinear"},
    {"name": "400mm", "focal_length": 400, "projection": "rectilinear"},
    {"name": "500mm", "focal_length": 500, "projection": "rectilinear"},
    {"name": "600mm", "focal_length": 600, "projection": "rectilinear"},
    {"name": "714mm (RASA 8)", "focal_length": 714, "projection": "rectilinear"},
    {"name": "800mm", "focal_length": 800, "projection": "rectilinear"},
    {"name": "1000mm", "focal_length": 1000, "projection": "rectilinear"},
    {"name": "1200mm", "focal_length": 1200, "projection": "rectilinear"},
    {"name": "1600mm", "focal_length": 1600, "projection": "rectilinear"},
    {"name": "2000mm", "focal_length": 2000, "projection": "rectilinear"},
    {"name": "2350mm (C9.25)", "focal_length": 2350, "projection": "rectilinear"},
    // ===== Custom =====
    {"name": "Custom", "focal_length": 0, "projection": "rectilinear"}
  ]
};
